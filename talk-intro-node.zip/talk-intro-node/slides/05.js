console.log('Hello \n');

setTimeout(() => {
  console.log('World!');
}, 2000);
