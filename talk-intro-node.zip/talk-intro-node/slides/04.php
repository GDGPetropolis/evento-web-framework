<?php

echo "Hello\n";
sleep(2);
echo "World";