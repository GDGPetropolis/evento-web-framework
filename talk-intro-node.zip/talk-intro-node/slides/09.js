// Módulo core
const http = require('http');

// Arquivo local
const arquivoLocal = require('./arquivoLocal');
const arquivoLocal = require('./arquivoLocal.js');

// Módulo na pasta node_modules
const express = require('express');
